package com.mycompany.loadbalancer;

import java.util.*;
import org.eclipse.paho.client.mqttv3.*;

public class TrafficEmulator {
    private final Queue<TrafficTask> waitingQueue = new LinkedList<>();
    private final Queue<TrafficTask> processingQueue = new LinkedList<>();
    private final Queue<TrafficTask> readyQueue = new LinkedList<>();
    private final List<Long> resources;
    private final List<TrafficTask> runningTasks;
    private final Random random = new Random();
    private final List<String> completedTasks = new ArrayList<>();
    private MqttClient mqttClient;
    private boolean mqttConnected = false;
    private final Object syncLock = new Object();

    public TrafficEmulator(int resourceCount) {
        resources = new ArrayList<>();
        runningTasks = new ArrayList<>();
        for(int i = 0; i < resourceCount; i++) {
            resources.add(0L);
            runningTasks.add(null);
        }

        try {
            String broker = "tcp://localhost:1883";
            String clientId = "lb-" + System.currentTimeMillis();
            mqttClient = new MqttClient(broker, clientId);
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true);
            mqttClient.connect(options);
            mqttConnected = true;
            System.out.println("[MQTT] Connected to " + broker);
        } catch(Exception e) {
            mqttConnected = false;
            System.out.println("[MQTT] Not connected");
        }
    }

    public void addTask(String taskName, int delayStart, int delayEnd) {
        synchronized(syncLock) {
            int start = delayStart;
            int end = delayEnd;
            if(end < start) {
                end = start;
            }

            int delay;
            if(end == start) {
                delay = start;
            } else {
                delay = start + random.nextInt((end - start) + 1);
            }

            TrafficTask task = new TrafficTask(taskName, delay);
            waitingQueue.offer(task);
            System.out.println("[Traffic] Added task: " + task.getName() + " delay: " + (task.getDelay() / 1000) + "s");
            publishProgress("Added task: " + task.getName() + " delay: " + (task.getDelay() / 1000) + "s");
        }
    }

    public void processTasks() {
        synchronized(syncLock) {
            long now = System.currentTimeMillis();

            for(int i = 0; i < resources.size() && !waitingQueue.isEmpty(); i++) {
                if(runningTasks.get(i) == null) {
                    TrafficTask task = waitingQueue.poll();
                    runningTasks.set(i, task);
                    processingQueue.offer(task);
                    resources.set(i, now + task.getDelay());
                    System.out.println("[Traffic] Resource " + (i + 1) + " started: " + task.getName());
                    publishProgress("Resource " + (i + 1) + " started: " + task.getName());
                }
            }

            now = System.currentTimeMillis();

            for(int i = 0; i < resources.size(); i++) {
                TrafficTask task = runningTasks.get(i);
                if(task != null && resources.get(i) > 0 && now >= resources.get(i)) {
                    runningTasks.set(i, null);
                    resources.set(i, 0L);
                    processingQueue.remove(task);
                    readyQueue.offer(task);
                    completedTasks.add(task.getName() + " - " + (task.getDelay() / 1000) + "s");
                    System.out.println("[Traffic] Resource " + (i + 1) + " completed: " + task.getName());
                    publishProgress("Resource " + (i + 1) + " completed: " + task.getName());
                }
            }
        }
    }

    public void showProgress() {
        synchronized(syncLock) {
            System.out.println("\n[Traffic] Progress:");
            System.out.println("  Waiting: " + waitingQueue.size());
            System.out.println("  Processing: " + processingQueue.size());
            System.out.println("  Ready: " + readyQueue.size());

            long now = System.currentTimeMillis();
            for(int i = 0; i < resources.size(); i++) {
                if(runningTasks.get(i) == null) {
                    System.out.println("  Resource " + (i + 1) + ": Free");
                } else {
                    long left = resources.get(i) - now;
                    if(left < 0) {
                        left = 0;
                    }
                    System.out.println("  Resource " + (i + 1) + ": " + (left / 1000) + "s remaining");
                }
            }

            publishProgress("Progress waiting=" + waitingQueue.size() + " processing=" + processingQueue.size() + " ready=" + readyQueue.size());
        }
    }

    public void showReadyQueue() {
        synchronized(syncLock) {
            System.out.println("\n[Traffic] Ready Queue:");
            for(TrafficTask t : readyQueue) {
                System.out.println("  " + t.getName() + " - " + (t.getDelay() / 1000) + "s");
            }
        }
    }

    public void showCompletedTasks() {
        synchronized(syncLock) {
            System.out.println("\n[Traffic] Completed Tasks:");
            for(String s : completedTasks) {
                System.out.println("  " + s);
            }
        }
    }

    public boolean allTasksReady() {
        synchronized(syncLock) {
            return waitingQueue.isEmpty() && processingQueue.isEmpty();
        }
    }

    public void disconnect() {
        synchronized(syncLock) {
            if(!mqttConnected) return;
            try {
                mqttClient.disconnect();
                mqttConnected = false;
                System.out.println("[MQTT] Disconnected");
            } catch(Exception e) {
            }
        }
    }

    private void publishProgress(String message) {
        if(!mqttConnected) return;
        try {
            mqttClient.publish("loadbalancer/progress", new MqttMessage(message.getBytes()));
        } catch(Exception e) {
        }
    }
}
