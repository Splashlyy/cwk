package com.mycompany.loadbalancer;

import java.util.*;

public class TaskQueue {
    private Queue<Task> pendingTasks;
    private Queue<Task> activeTasks;
    private Queue<Task> doneTasks;
    
    private List<Long> workers;
    private int numWorkers;

    public TaskQueue(int workerCount) {
        pendingTasks = new LinkedList<>();
        activeTasks = new LinkedList<>();
        doneTasks = new LinkedList<>();
        
        numWorkers = workerCount;
        workers = new ArrayList<>();
        
        for(int i = 0; i < workerCount; i++) {
            workers.add(0L);
        }
    }

    public void submitTask(Task job) {
        pendingTasks.add(job);
        System.out.println("Task submitted: " + job.name);
    }


    public void tick() {
        for(int i = 0; i < numWorkers; i++) {
            Long workerStatus = workers.get(i);
            
            if(workerStatus == 0 && !pendingTasks.isEmpty()) {
                Task job = pendingTasks.poll();
                activeTasks.add(job);
                
                long finishTime = System.currentTimeMillis() + (job.duration * 1000L);
                workers.set(i, finishTime);
                
                System.out.println("Worker " + (i+1) + " picked up: " + job.name);
            }
        }

        Iterator<Task> iter = activeTasks.iterator();
        int idx = 0;
        
        while(iter.hasNext() && idx < numWorkers) {
            Task job = iter.next();
            Long workerStatus = workers.get(idx);
            
            if(workerStatus > 0 && System.currentTimeMillis() >= workerStatus) {
                iter.remove();
                doneTasks.add(job);
                workers.set(idx, 0L);
                System.out.println("Worker " + (idx+1) + " completed: " + job.name);
            }
            
            idx++;
        }
    }

    public void printStatus() {
        System.out.println("Pending: " + pendingTasks.size() + 
                         " | Active: " + activeTasks.size() + 
                         " | Done: " + doneTasks.size());
    }


    public boolean allDone() {
        return pendingTasks.isEmpty() && activeTasks.isEmpty();
    }

    public int getDoneCount() {
        return doneTasks.size();
    }
}