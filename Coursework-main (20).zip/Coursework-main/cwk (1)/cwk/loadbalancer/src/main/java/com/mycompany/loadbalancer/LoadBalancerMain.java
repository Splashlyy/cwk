package com.mycompany.loadbalancer;

import java.util.*;

public class LoadBalancerMain {
    
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("  LOAD BALANCER STARTED");
        System.out.println("========================================");
        
        List<Task> tasks = new ArrayList<>();
        tasks.add(new Task("Upload1", 5));
        tasks.add(new Task("Upload2", 8));
        tasks.add(new Task("Download1", 3));
        tasks.add(new Task("Upload3", 10));
        
        System.out.println("\nTesting Round Robin:");
        Scheduler s1 = new Scheduler(tasks);
        long rrTime = s1.roundRobin(3);
        System.out.println("RR Total: " + rrTime + "s\n");
        
        System.out.println("\nTesting SJF:");
        Scheduler s2 = new Scheduler(tasks);
        long sjfTime = s2.shortestJobFirst();
        System.out.println("SJF Total: " + sjfTime + "s\n");
        
        System.out.println("\nTesting FCFS:");
        Scheduler s3 = new Scheduler(tasks);
        long fcfsTime = s3.firstComeFirstServe();
        System.out.println("FCFS Total: " + fcfsTime + "s\n");

        System.out.println("\nTesting Traffic Emulation:");
        TrafficEmulator te = new TrafficEmulator(4);

        Thread producer = new Thread(new Runnable() {
            public void run() {
                Random r = new Random();
                for(int i = 1; i <= 20; i++) {
                    te.addTask("Task" + i, 2000, 4000);
                    try {
                        Thread.sleep(100 + r.nextInt(400));
                    } catch(Exception e) {
                    }
                }
            }
        });
        producer.start();

        while(producer.isAlive() || !te.allTasksReady()) {
            te.processTasks();
            te.showProgress();
            try {
                Thread.sleep(1000);
            } catch(Exception e) {
                e.printStackTrace();
            }
        }

        try {
            producer.join();
        } catch(Exception e) {
        }

        te.showReadyQueue();
        te.showCompletedTasks();
        te.disconnect();
        
        System.out.println("========================================");
        System.out.println("  LOAD BALANCER RUNNING...");
        System.out.println("========================================");
        
        try {
            Thread.sleep(Long.MAX_VALUE);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}//hi
