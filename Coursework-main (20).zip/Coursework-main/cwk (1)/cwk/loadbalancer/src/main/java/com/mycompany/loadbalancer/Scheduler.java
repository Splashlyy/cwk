package com.mycompany.loadbalancer;

import com.mycompany.loadbalancer.Task;
import java.util.*;

public class Scheduler {
    private static final int SERVERS = 4;
    private static final int ARTIFICIAL_DELAY_MIN = 30;
    private static final int ARTIFICIAL_DELAY_MAX = 90;
    private final Random artificialDelayRandom = new Random();
    private final Map<String,Integer> artificialDelayByTask = new HashMap<>();
    private List<Long> serverLoad;
    private List<Task> taskList;

    public Scheduler(List<Task> tasks) {
        this.taskList = tasks;
        this.serverLoad = new ArrayList<>();
        for(int i = 0; i < SERVERS; i++) {
            serverLoad.add(0L);
        }
    }


    private int getArtificialDelaySeconds(String taskName) {
        Integer v = artificialDelayByTask.get(taskName);
        if(v != null) return v;
        int range = (ARTIFICIAL_DELAY_MAX - ARTIFICIAL_DELAY_MIN) + 1;
        int d = ARTIFICIAL_DELAY_MIN + artificialDelayRandom.nextInt(range);
        artificialDelayByTask.put(taskName, d);
        return d;
    }


    public long roundRobin(int quantum) {
        System.out.println("RR: quantum=" + quantum);
        LoadBalancerMetrics.reset();
        
        Queue<Task> taskQueue = new LinkedList<>();
        for(Task t : taskList) {
            t.remainingTime = t.duration;
            taskQueue.add(t);
            LoadBalancerMetrics.recordTaskArrival();
        }

        int idx = 0;
        while(!taskQueue.isEmpty()) {
            Task current = taskQueue.poll();
            int srv = idx % SERVERS;
            int delay = 0;
            if(current.remainingTime == current.duration) {
                delay = getArtificialDelaySeconds(current.name);
                serverLoad.set(srv, serverLoad.get(srv) + delay);
            }

            if(current.remainingTime > quantum) {
                long oldTime = serverLoad.get(srv);
                serverLoad.set(srv, oldTime + quantum);
                current.remainingTime = current.remainingTime - quantum;
                taskQueue.add(current);
                if(delay > 0) System.out.println("S" + (srv+1) + ": " + current.name + " delay " + delay + "s + ran " + quantum + "s (left: " + current.remainingTime + ")");
                else System.out.println("S" + (srv+1) + ": " + current.name + " ran " + quantum + "s (left: " + current.remainingTime + ")");
            } else {
                serverLoad.set(srv, serverLoad.get(srv) + current.remainingTime);
                LoadBalancerMetrics.recordTaskCompleted(delay + current.remainingTime);
                if(delay > 0) System.out.println("S" + (srv+1) + ": " + current.name + " delay " + delay + "s + done in " + current.remainingTime + "s");
                else System.out.println("S" + (srv+1) + ": " + current.name + " done in " + current.remainingTime + "s");
            }
            idx++;
        }

        long max = 0;
        for(Long time : serverLoad) {
            if(time > max) max = time;
        }
        
        System.out.println("Metrics: " + LoadBalancerMetrics.getSummary());
        return max;
    }

    public long shortestJobFirst() {
        System.out.println("SJF");
        LoadBalancerMetrics.reset();
        
        List<Task> sortedTasks = new ArrayList<>(taskList);
        sortedTasks.sort(new Comparator<Task>() {
            public int compare(Task a, Task b) {
                return a.duration - b.duration;
            }
        });

        int idx = 0;
        for(Task t : sortedTasks) {
            t.remainingTime = t.duration;
            LoadBalancerMetrics.recordTaskArrival();
            int srv = idx % SERVERS;
            int delay = getArtificialDelaySeconds(t.name);
            serverLoad.set(srv, serverLoad.get(srv) + delay + t.duration);
            LoadBalancerMetrics.recordTaskCompleted(delay + t.duration);
            System.out.println("S" + (srv+1) + ": " + t.name + " -> " + t.duration + "s (delay " + delay + "s)");
            idx++;
        }

        long max = 0;
        for(Long time : serverLoad) {
            if(time > max) max = time;
        }
        
        System.out.println("Metrics: " + LoadBalancerMetrics.getSummary());
        return max;
    }


    public long firstComeFirstServe() {
        System.out.println("FCFS");
        LoadBalancerMetrics.reset();
        
        Queue<Task> queue = new LinkedList<>();
        for(Task t : taskList) {
            t.remainingTime = t.duration;
            queue.add(t);
            LoadBalancerMetrics.recordTaskArrival();
        }

        int idx = 0;
        while(!queue.isEmpty()) {
            Task t = queue.poll();
            int srv = idx % SERVERS;
            int delay = getArtificialDelaySeconds(t.name);
            serverLoad.set(srv, serverLoad.get(srv) + delay + t.duration);
            LoadBalancerMetrics.recordTaskCompleted(delay + t.duration);
            System.out.println("S" + (srv+1) + ": " + t.name + " -> " + t.duration + "s (delay " + delay + "s)");
            idx++;
        }

        long max = 0;
        for(Long time : serverLoad) {
            if(time > max) max = time;
        }
        
        System.out.println("Metrics: " + LoadBalancerMetrics.getSummary());
        return max;
    }

    public void showServerLoad() {
        System.out.println("Server load:");
        for(int i = 0; i < SERVERS; i++) {
            System.out.println("  S" + (i+1) + ": " + serverLoad.get(i) + "s");
        }
    }
}