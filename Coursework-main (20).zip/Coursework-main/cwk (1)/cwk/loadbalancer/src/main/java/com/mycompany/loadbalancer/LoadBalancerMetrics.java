package com.mycompany.loadbalancer;

public class LoadBalancerMetrics{
    private static int totalTasks=0;
    private static int completedTasks=0;
    private static int failedTasks=0;
    private static long totalProcessingTime=0;
    private static long startTime=System.currentTimeMillis();
    
    public static void recordTaskArrival(){
        totalTasks++;
    }
    
    public static void recordTaskCompleted(long processingTimeMs){
        completedTasks++;
        totalProcessingTime+=processingTimeMs;
    }
    
    public static void recordTaskFailed(){
        failedTasks++;
    }
    
    public static int getTotalTasks(){
        return totalTasks;
    }
    
    public static int getCompletedTasks(){
        return completedTasks;
    }
    
    public static int getFailedTasks(){
        return failedTasks;
    }
    
    public static long getAverageProcessingTime(){
        return completedTasks==0?0:totalProcessingTime/completedTasks;
    }
    
    public static double getThroughput(){
        long elapsed=System.currentTimeMillis()-startTime;
        return elapsed==0?0:(completedTasks*1000.0)/elapsed;
    }
    
    public static String getSummary(){
        return "Total:"+totalTasks+" Completed:"+completedTasks+" Failed:"+failedTasks+
               " AvgMs:"+getAverageProcessingTime()+" Throughput:"+getThroughput();
    }
    
    public static void reset(){
        totalTasks=0;
        completedTasks=0;
        failedTasks=0;
        totalProcessingTime=0;
        startTime=System.currentTimeMillis();
    }
}