package com.mycompany.loadbalancer;

public class Task {
    String name;
    int duration;
    int remainingTime;

    public Task(String name, int duration) {
        this.name = name;
        this.duration = duration;
        this.remainingTime = duration;
    }
}