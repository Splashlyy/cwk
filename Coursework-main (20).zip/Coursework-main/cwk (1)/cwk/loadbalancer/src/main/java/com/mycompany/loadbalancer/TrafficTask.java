package com.mycompany.loadbalancer;

public class TrafficTask {
    private String name;
    private int delay;
    private long startTime;

    public TrafficTask(String name, int delay) {
        this.name = name;
        this.delay = delay;
        this.startTime = System.currentTimeMillis();
    }

    public String getName() {
        return name;
    }

    public int getDelay() {
        return delay;
    }

    public long getStartTime() {
        return startTime;
    }
}
