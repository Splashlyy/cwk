package com.mycompany.javafxapplication1;

public class Metrics{
    private static long firstCommandTimeMilliseconds=0;
    private static int commandCount=0;
    private static long totalDurationMilliseconds=0;
    private static long lastDurationMilliseconds=0;

    public static void reset(){
        firstCommandTimeMilliseconds=0;
        commandCount=0;
        totalDurationMilliseconds=0;
        lastDurationMilliseconds=0;
    }

    public static void record(long durationMilliseconds){
        if(commandCount==0)firstCommandTimeMilliseconds=System.currentTimeMillis();
        commandCount++;
        totalDurationMilliseconds+=durationMilliseconds;
        lastDurationMilliseconds=durationMilliseconds;
    }

    public static int getCommandCount(){return commandCount;}
    public static long getLastDuration(){return lastDurationMilliseconds;}
    public static long getAverageDuration(){return commandCount==0?0:totalDurationMilliseconds/commandCount;}
    public static double getThroughput(){
        if(commandCount==0)return 0;
        long elapsedMilliseconds=System.currentTimeMillis()-firstCommandTimeMilliseconds;
        if(elapsedMilliseconds<=0)return 0;
        return (commandCount*1000.0)/elapsedMilliseconds;
    }

    public static String text(){
        return "Commands:"+getCommandCount()+" LastMs:"+getLastDuration()+" AvgMs:"+getAverageDuration()+" Throughput:"+getThroughput();
    }
}
