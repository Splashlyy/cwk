package com.mycompany.javafxapplication1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class MySQLDB{
    private String dataBaseName="comp20081db";
    private String dataBaseTableName="Users";
    private String fileAclTableName="FileACL";
    private String fileShareTableName="FileShare";
    private String fileMetaTableName="FileMeta";
    private String userName="admin";
    private String userPassword="RbJHPd1KbCAg";
    private Connection connection=null;

    public void createConnection() throws ClassNotFoundException{
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection=DriverManager.getConnection("jdbc:mysql://lamp-server:3306/"+dataBaseName+"?useSSL=false",userName,userPassword);
        }catch(SQLException ex){
            try{
                connection=DriverManager.getConnection("jdbc:mysql://lamp-server:3306/?useSSL=false",userName,userPassword);
                Statement statement=connection.createStatement();
                statement.executeUpdate("create database if not exists "+dataBaseName);
                connection.close();
                connection=DriverManager.getConnection("jdbc:mysql://lamp-server:3306/"+dataBaseName+"?useSSL=false",userName,userPassword);
            }catch(SQLException ex2){
                Logger.getLogger(MySQLDB.class.getName()).log(Level.SEVERE,null,ex2);
            }
        }
    }

    public void createTables() throws ClassNotFoundException{
        try{
            createConnection();
            Statement statement=connection.createStatement();
            statement.executeUpdate("create table if not exists "+dataBaseTableName+" (name varchar(255) primary key, password varchar(255), role varchar(50) default 'standard')");
            statement.executeUpdate("create table if not exists "+fileAclTableName+" (filename varchar(1024) primary key, owner varchar(255))");
            statement.executeUpdate("create table if not exists "+fileShareTableName+" (filename varchar(1024), username varchar(255), canWrite integer, primary key(filename, username))");
            statement.executeUpdate("create table if not exists "+fileMetaTableName+" (filename varchar(1024) primary key, owner varchar(255), size bigint, action varchar(50), updated bigint)");
        }catch(SQLException ex){
            Logger.getLogger(MySQLDB.class.getName()).log(Level.SEVERE,null,ex);
        }finally{
            try{
                if(connection!=null){
                    connection.close();
                }
            }catch(SQLException e){
                System.err.println(e.getMessage());
            }
        }
    }

    public void addDataToDB(String user,String password) throws ClassNotFoundException{
        try{
            createConnection();
            String insertQueryStatement="INSERT INTO "+dataBaseTableName+" (name, password) VALUES (?,?)";
            PreparedStatement preparedStmt=connection.prepareStatement(insertQueryStatement);
            preparedStmt.setString(1,user);
            preparedStmt.setString(2,password);
            preparedStmt.execute();
        }catch(SQLException ex){
            Logger.getLogger(MySQLDB.class.getName()).log(Level.SEVERE,null,ex);
        }finally{
            try{
                if(connection!=null){
                    connection.close();
                }
            }catch(SQLException e){
                System.err.println(e.getMessage());
            }
        }
    }

    public void addDataToDB(String user,String password,String role) throws ClassNotFoundException{
        try{
            createConnection();
            String insertQueryStatement="INSERT INTO "+dataBaseTableName+" (name, password, role) VALUES (?,?,?) ON DUPLICATE KEY UPDATE password=VALUES(password), role=VALUES(role)";
            PreparedStatement preparedStmt=connection.prepareStatement(insertQueryStatement);
            preparedStmt.setString(1,user);
            preparedStmt.setString(2,password);
            preparedStmt.setString(3,role);
            preparedStmt.execute();
        }catch(SQLException ex){
            Logger.getLogger(MySQLDB.class.getName()).log(Level.SEVERE,null,ex);
        }finally{
            try{
                if(connection!=null){
                    connection.close();
                }
            }catch(SQLException e){
                System.err.println(e.getMessage());
            }
        }
    }

    public boolean setFileOwner(String filename,String owner) throws ClassNotFoundException{
        int rows=0;
        try{
            createConnection();
            String deleteAcl="delete from "+fileAclTableName+" where filename = ?";
            PreparedStatement ps1=connection.prepareStatement(deleteAcl);
            ps1.setString(1,filename);
            ps1.executeUpdate();
            String deleteShare="delete from "+fileShareTableName+" where filename = ?";
            PreparedStatement ps2=connection.prepareStatement(deleteShare);
            ps2.setString(1,filename);
            ps2.executeUpdate();
            String insertQueryStatement="insert into "+fileAclTableName+" (filename, owner) values(?,?)";
            PreparedStatement preparedStmt=connection.prepareStatement(insertQueryStatement);
            preparedStmt.setString(1,filename);
            preparedStmt.setString(2,owner);
            rows=preparedStmt.executeUpdate();
        }catch(SQLException ex){
            Logger.getLogger(MySQLDB.class.getName()).log(Level.SEVERE,null,ex);
        }finally{
            try{
                if(connection!=null){
                    connection.close();
                }
            }catch(SQLException e){
                System.err.println(e.getMessage());
            }
        }
        return rows>0;
    }

    public boolean setFileShare(String filename,String username,int canWrite) throws ClassNotFoundException{
        int rows=0;
        try{
            createConnection();
            String insertQueryStatement="INSERT INTO "+fileShareTableName+" (filename, username, canWrite) VALUES (?,?,?) ON DUPLICATE KEY UPDATE canWrite=VALUES(canWrite)";
            PreparedStatement preparedStmt=connection.prepareStatement(insertQueryStatement);
            preparedStmt.setString(1,filename);
            preparedStmt.setString(2,username);
            preparedStmt.setInt(3,canWrite);
            rows=preparedStmt.executeUpdate();
        }catch(SQLException ex){
            Logger.getLogger(MySQLDB.class.getName()).log(Level.SEVERE,null,ex);
        }finally{
            try{
                if(connection!=null){
                    connection.close();
                }
            }catch(SQLException e){
                System.err.println(e.getMessage());
            }
        }
        return rows>0;
    }

    public boolean removeFileShare(String filename,String username) throws ClassNotFoundException{
        int rows=0;
        try{
            createConnection();
            String deleteQueryStatement="delete from "+fileShareTableName+" where filename = ? and username = ?";
            PreparedStatement preparedStmt=connection.prepareStatement(deleteQueryStatement);
            preparedStmt.setString(1,filename);
            preparedStmt.setString(2,username);
            rows=preparedStmt.executeUpdate();
        }catch(SQLException ex){
            Logger.getLogger(MySQLDB.class.getName()).log(Level.SEVERE,null,ex);
        }finally{
            try{
                if(connection!=null){
                    connection.close();
                }
            }catch(SQLException e){
                System.err.println(e.getMessage());
            }
        }
        return rows>0;
    }

    public boolean upsertFileMeta(String filename,String owner,long size,String action) throws ClassNotFoundException{
        int rows=0;
        long updated=System.currentTimeMillis();
        try{
            createConnection();
            String insertQueryStatement="INSERT INTO "+fileMetaTableName+" (filename, owner, size, action, updated) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE owner=VALUES(owner), size=VALUES(size), action=VALUES(action), updated=VALUES(updated)";
            PreparedStatement preparedStmt=connection.prepareStatement(insertQueryStatement);
            preparedStmt.setString(1,filename);
            preparedStmt.setString(2,owner);
            preparedStmt.setLong(3,size);
            preparedStmt.setString(4,action);
            preparedStmt.setLong(5,updated);
            rows=preparedStmt.executeUpdate();
        }catch(SQLException ex){
            Logger.getLogger(MySQLDB.class.getName()).log(Level.SEVERE,null,ex);
        }finally{
            try{
                if(connection!=null){
                    connection.close();
                }
            }catch(SQLException e){
                System.err.println(e.getMessage());
            }
        }
        return rows>0;
    }

    public boolean deleteFileMeta(String filename) throws ClassNotFoundException{
        int rows=0;
        try{
            createConnection();
            String deleteQueryStatement="delete from "+fileMetaTableName+" where filename = ?";
            PreparedStatement preparedStmt=connection.prepareStatement(deleteQueryStatement);
            preparedStmt.setString(1,filename);
            rows=preparedStmt.executeUpdate();
        }catch(SQLException ex){
            Logger.getLogger(MySQLDB.class.getName()).log(Level.SEVERE,null,ex);
        }finally{
            try{
                if(connection!=null){
                    connection.close();
                }
            }catch(SQLException e){
                System.err.println(e.getMessage());
            }
        }
        return rows>0;
    }

    public void deleteFileAclAndShare(String filename) throws ClassNotFoundException{
        try{
            createConnection();
            String deleteAcl="delete from "+fileAclTableName+" where filename = ?";
            PreparedStatement ps1=connection.prepareStatement(deleteAcl);
            ps1.setString(1,filename);
            ps1.executeUpdate();
            String deleteShare="delete from "+fileShareTableName+" where filename = ?";
            PreparedStatement ps2=connection.prepareStatement(deleteShare);
            ps2.setString(1,filename);
            ps2.executeUpdate();
        }catch(SQLException ex){
            Logger.getLogger(MySQLDB.class.getName()).log(Level.SEVERE,null,ex);
        }finally{
            try{
                if(connection!=null){
                    connection.close();
                }
            }catch(SQLException e){
                System.err.println(e.getMessage());
            }
        }
    }

    public ObservableList<User> getDataFromTable(String tabName) throws ClassNotFoundException{
        ObservableList<User> userList=FXCollections.observableArrayList();
        try{
            createConnection();
            Statement statement=connection.createStatement();
            ResultSet resultSet=statement.executeQuery("SELECT * FROM "+tabName);
            while(resultSet.next()){
                String name=resultSet.getString("name");
                String password=resultSet.getString("password");
                try{
                    String role=resultSet.getString("role");
                    userList.add(new User(name,password,role));
                }catch(SQLException ex){
                    userList.add(new User(name,password));
                }
            }
        }catch(SQLException ex){
            Logger.getLogger(MySQLDB.class.getName()).log(Level.SEVERE,null,ex);
        }finally{
            try{
                if(connection!=null){
                    connection.close();
                }
            }catch(SQLException e){
                System.err.println(e.getMessage());
            }
        }
        return userList;
    }

    public boolean validateUser(String user,String pass,String tabName) throws ClassNotFoundException{
        boolean valid=false;
        try{
            createConnection();
            Statement statement=connection.createStatement();
            ResultSet resultSet=statement.executeQuery("SELECT * FROM "+tabName);
            while(resultSet.next()){
                String name=resultSet.getString("name");
                String password=resultSet.getString("password");
                if(name.equals(user)&&password.equals(pass)){
                    valid=true;
                    break;
                }
            }
        }catch(SQLException ex){
            Logger.getLogger(MySQLDB.class.getName()).log(Level.SEVERE,null,ex);
        }finally{
            try{
                if(connection!=null){
                    connection.close();
                }
            }catch(SQLException e){
                System.err.println(e.getMessage());
            }
        }
        return valid;
    }
}
