package com.mycompany.javafxapplication1;

import java.io.IOException;
import java.security.spec.InvalidKeySpecException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class PrimaryController{
    @FXML private TextField userTextField;
    @FXML private PasswordField passPasswordField;
    @FXML private Button primaryButton;
    @FXML private Button registerBtn;

    @FXML private void switchToSecondary() throws IOException{
        String user=userTextField.getText();
        String pass=passPasswordField.getText();
        try{
            DB myObj=new DB();
            if(myObj.validateUser(user,pass)){
                myObj.createSession(user);
                AppLog.log("User logged in: "+user);
                
                String role=myObj.getUserRole(user);
                MySQLDB mysql=new MySQLDB();
                try{
                    mysql.addDataToDB(user,myObj.generateSecurePassword(pass),role);
                }catch(Exception e){}
                
                Stage secondaryStage=new Stage();
                Stage primaryStage=(Stage)primaryButton.getScene().getWindow();
                FXMLLoader loader=new FXMLLoader();
                loader.setLocation(getClass().getResource("secondary.fxml"));
                Parent root=loader.load();
                SecondaryController secondaryController=loader.getController();
                String[] credentials={user,role};
                secondaryController.initialise(credentials);
                Scene scene=new Scene(root,640,720);
                secondaryStage.setScene(scene);
                secondaryStage.setTitle("Main");
                secondaryStage.show();
                primaryStage.close();
            }
        }catch(InvalidKeySpecException|ClassNotFoundException ex){
            Logger.getLogger(PrimaryController.class.getName()).log(Level.SEVERE,null,ex);
        }
    }

    @FXML private void registerBtnHandler(ActionEvent event){
        try{
            Stage registerStage=new Stage();
            Stage primaryStage=(Stage)registerBtn.getScene().getWindow();
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource("register.fxml"));
            Parent root=loader.load();
            Scene scene=new Scene(root,640,480);
            registerStage.setScene(scene);
            registerStage.setTitle("Register");
            registerStage.show();
            primaryStage.close();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}