/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.javafxapplication1;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class DB {
    private String fileName = "jdbc:sqlite:comp20081.db";
    private int timeout = 30;
    private String dataBaseName = "COMP20081";
    private String dataBaseTableName = "Users";
    private String sessionTableName = "Sessions";
    private String fileAclTableName = "FileACL";
    private String fileShareTableName = "FileShare";
    private String fileMetaTableName = "FileMeta";
    Connection connection = null;
    private Random random = new SecureRandom();
    private String characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private int iterations = 10000;
    private int keylength = 256;
    private String saltValue;
    
    DB() {
        try {
            File fp = new File(".salt");
            if (!fp.exists()) {
                saltValue = this.getSaltvalue(30);
                FileWriter myWriter = new FileWriter(fp);
                myWriter.write(saltValue);
                myWriter.close();
            } else {
                Scanner myReader = new Scanner(fp);
                while (myReader.hasNextLine()) {
                    saltValue = myReader.nextLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
        
    public void createTable(String tableName) throws ClassNotFoundException {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            var statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + tableName + "(id integer primary key autoincrement, name string, password string, role string)");

        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
    }

    public void createSessionTable() throws ClassNotFoundException {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            var statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + sessionTableName + "(id integer primary key autoincrement, username string, token string, created integer)");
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
    }

    public void createFileAclTable() throws ClassNotFoundException {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            var statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + fileAclTableName + "(id integer primary key autoincrement, filename string, owner string)");
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
    }

    public void createFileShareTable() throws ClassNotFoundException {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            var statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + fileShareTableName + "(id integer primary key autoincrement, filename string, username string, canWrite integer)");
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
    }

    public void createFileMetaTable() throws ClassNotFoundException {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            var statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + fileMetaTableName + "(id integer primary key autoincrement, filename string, owner string, size integer, action string, updated integer)");
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
    }

    public boolean setFileOwner(String filename,String owner) throws ClassNotFoundException {
        int rows = 0;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + fileAclTableName + "(id integer primary key autoincrement, filename string, owner string)");
            statement.executeUpdate("create table if not exists " + fileShareTableName + "(id integer primary key autoincrement, filename string, username string, canWrite integer)");
            statement.executeUpdate("delete from " + fileAclTableName + " where filename = '" + filename + "'");
            statement.executeUpdate("delete from " + fileShareTableName + " where filename = '" + filename + "'");
            rows = statement.executeUpdate("insert into " + fileAclTableName + " (filename, owner) values('" + filename + "','" + owner + "')");
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
        return rows > 0;
    }

    public String getFileOwner(String filename) throws ClassNotFoundException {
        String owner = null;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + fileAclTableName + "(id integer primary key autoincrement, filename string, owner string)");
            ResultSet rs = statement.executeQuery("select owner from " + fileAclTableName + " where filename = '" + filename + "'");
            if (rs.next()) {
                owner = rs.getString("owner");
            }
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
        return owner;
    }

    public boolean setFileShare(String filename,String username,int canWrite) throws ClassNotFoundException {
        int rows = 0;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + fileShareTableName + "(id integer primary key autoincrement, filename string, username string, canWrite integer)");
            statement.executeUpdate("delete from " + fileShareTableName + " where filename = '" + filename + "' and username = '" + username + "'");
            rows = statement.executeUpdate("insert into " + fileShareTableName + " (filename, username, canWrite) values('" + filename + "','" + username + "'," + canWrite + ")");
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
        return rows > 0;
    }

    public boolean removeFileShare(String filename,String username) throws ClassNotFoundException {
        int rows = 0;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + fileShareTableName + "(id integer primary key autoincrement, filename string, username string, canWrite integer)");
            rows = statement.executeUpdate("delete from " + fileShareTableName + " where filename = '" + filename + "' and username = '" + username + "'");
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
        return rows > 0;
    }

    public int getFileShareCanWrite(String filename,String username) throws ClassNotFoundException {
        int canWrite = -1;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + fileShareTableName + "(id integer primary key autoincrement, filename string, username string, canWrite integer)");
            ResultSet rs = statement.executeQuery("select canWrite from " + fileShareTableName + " where filename = '" + filename + "' and username = '" + username + "'");
            if (rs.next()) {
                canWrite = rs.getInt("canWrite");
            }
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
        return canWrite;
    }

    public boolean upsertFileMeta(String filename,String owner,long size,String action) throws ClassNotFoundException {
        int rows = 0;
        long updated = System.currentTimeMillis();
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + fileMetaTableName + "(id integer primary key autoincrement, filename string, owner string, size integer, action string, updated integer)");
            statement.executeUpdate("delete from " + fileMetaTableName + " where filename = '" + filename + "'");
            rows = statement.executeUpdate("insert into " + fileMetaTableName + " (filename, owner, size, action, updated) values('" + filename + "','" + owner + "'," + size + ",'" + action + "'," + updated + ")");
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
        return rows > 0;
    }

    public boolean deleteFileMeta(String filename) throws ClassNotFoundException {
        int rows = 0;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + fileMetaTableName + "(id integer primary key autoincrement, filename string, owner string, size integer, action string, updated integer)");
            rows = statement.executeUpdate("delete from " + fileMetaTableName + " where filename = '" + filename + "'");
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
        return rows > 0;
    }

    public String getFileMetaSummary(String filename) throws ClassNotFoundException {
        String summary = null;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + fileMetaTableName + "(id integer primary key autoincrement, filename string, owner string, size integer, action string, updated integer)");
            ResultSet rs = statement.executeQuery("select owner, size, action from " + fileMetaTableName + " where filename = '" + filename + "'");
            if (rs.next()) {
                summary = "Cache owner:" + rs.getString("owner") + " size:" + rs.getLong("size") + " action:" + rs.getString("action");
            }
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
        return summary;
    }

    public String createSession(String username) throws ClassNotFoundException {
        String token = getSaltvalue(40);
        long created = System.currentTimeMillis();
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + sessionTableName + "(id integer primary key autoincrement, username string, token string, created integer)");
            statement.executeUpdate("delete from " + sessionTableName + " where username = '" + username + "'");
            statement.executeUpdate("insert into " + sessionTableName + " (username, token, created) values('" + username + "','" + token + "'," + created + ")");
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
        return token;
    }

    public boolean deleteSession(String token) throws ClassNotFoundException {
        int rows = 0;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            rows = statement.executeUpdate("delete from " + sessionTableName + " where token = '" + token + "'");
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
        return rows > 0;
    }

    public void delTable(String tableName) throws ClassNotFoundException {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            var statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("drop table if exists " + tableName);
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
    }

    public void addDataToDB(String user, String password) throws InvalidKeySpecException, ClassNotFoundException {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            var statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            int count = 0;
            ResultSet countRs = statement.executeQuery("select count(*) as c from " + dataBaseTableName);
            if (countRs.next()) {
                count = countRs.getInt("c");
            }
            String role = count == 0 ? "admin" : "standard";
            statement.executeUpdate("insert into " + dataBaseTableName + " (name, password, role) values('" + user + "','" + generateSecurePassword(password) + "','" + role + "')");
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    if (connection != null) {
                        connection.close();
                    }
                } catch (SQLException e) {
                    System.err.println(e.getMessage());
                }
            }
        }
    }

    public ObservableList<User> getDataFromTable() throws ClassNotFoundException {
        ObservableList<User> result = FXCollections.observableArrayList();
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            var statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            ResultSet rs = statement.executeQuery("select * from " + this.dataBaseTableName);
            while (rs.next()) {
                result.add(new User(rs.getString("name"),rs.getString("password"),rs.getString("role")));
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
        return result;
    }

    public String getUserRole(String user) throws ClassNotFoundException {
        String role = "standard";
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            var statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            ResultSet rs = statement.executeQuery("select role from " + this.dataBaseTableName + " where name = '" + user + "'");
            if (rs.next()) {
                String r = rs.getString("role");
                if (r != null && !r.trim().isEmpty()) {
                    role = r;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
        return role;
    }

    public boolean validateUser(String user, String pass) throws InvalidKeySpecException, ClassNotFoundException {
        Boolean flag = false;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            var statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            ResultSet rs = statement.executeQuery("select name, password from " + this.dataBaseTableName);
            String inPass = generateSecurePassword(pass);
            while (rs.next()) {
                if (user.equals(rs.getString("name")) && rs.getString("password").equals(inPass)) {
                    flag = true;
                    break;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }

        return flag;
    }

    private String getSaltvalue(int length) {
        StringBuilder finalval = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            finalval.append(characters.charAt(random.nextInt(characters.length())));
        }

        return new String(finalval);
    }

    private byte[] hash(char[] password, byte[] salt) throws InvalidKeySpecException {
        PBEKeySpec spec = new PBEKeySpec(password, salt, iterations, keylength);
        Arrays.fill(password, Character.MIN_VALUE);
        try {
            SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            return skf.generateSecret(spec).getEncoded();
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new AssertionError("Error while hashing a password: " + e.getMessage(), e);
        } finally {
            spec.clearPassword();
        }
    }

    public String generateSecurePassword(String password) throws InvalidKeySpecException {
        String finalval = null;

        byte[] securePassword = hash(password.toCharArray(), saltValue.getBytes());

        finalval = Base64.getEncoder().encodeToString(securePassword);

        return finalval;
    }

    private SecretKeySpec getFileKey(){
        byte[] keyBytes=new byte[16];
        byte[] saltBytes=saltValue==null?new byte[0]:saltValue.getBytes(StandardCharsets.UTF_8);
        int len=Math.min(saltBytes.length,16);
        for(int i=0;i<len;i++)keyBytes[i]=saltBytes[i];
        return new SecretKeySpec(keyBytes,"AES");
    }

    public String encryptText(String plainText){
        try{
            if(plainText==null)plainText="";
            Cipher cipher=Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE,getFileKey());
            byte[] encrypted=cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(encrypted);
        }catch(Exception e){
            return null;
        }
    }

    public String decryptText(String encryptedText){
        try{
            if(encryptedText==null)return null;
            String trimmed=encryptedText.trim();
            if(trimmed.isEmpty())return "";
            Cipher cipher=Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE,getFileKey());
            byte[] decoded=Base64.getDecoder().decode(trimmed);
            byte[] plain=cipher.doFinal(decoded);
            return new String(plain,StandardCharsets.UTF_8);
        }catch(Exception e){
            return null;
        }
    }

    public String getTableName() {
        return this.dataBaseTableName;
    }

    public void log(String message) {
        System.out.println(message);

    }
    public boolean deleteUserByName(String username) throws ClassNotFoundException{
    int rows=0;
    try{
        Class.forName("org.sqlite.JDBC");
        connection=DriverManager.getConnection(fileName);
        Statement statement=connection.createStatement();
        statement.setQueryTimeout(timeout);
        rows=statement.executeUpdate("delete from "+dataBaseTableName+" where name = '"+username+"'");
    }catch(SQLException ex){
        Logger.getLogger(DB.class.getName()).log(Level.SEVERE,null,ex);
    }finally{
        try{
            if(connection!=null)connection.close();
        }catch(SQLException e){
            System.err.println(e.getMessage());
        }
    }
    return rows>0;
}

public boolean updateUserName(String oldUsername,String newUsername) throws ClassNotFoundException{
    int rows=0;
    try{
        Class.forName("org.sqlite.JDBC");
        connection=DriverManager.getConnection(fileName);
        Statement statement=connection.createStatement();
        statement.setQueryTimeout(timeout);
        rows=statement.executeUpdate("update "+dataBaseTableName+" set name = '"+newUsername+"' where name = '"+oldUsername+"'");
    }catch(SQLException ex){
        Logger.getLogger(DB.class.getName()).log(Level.SEVERE,null,ex);
    }finally{
        try{
            if(connection!=null)connection.close();
        }catch(SQLException e){
            System.err.println(e.getMessage());
        }
    }
    return rows>0;
}

}
