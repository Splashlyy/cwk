package com.mycompany.javafxapplication1;
import java.io.FileWriter;

public class AppLog{
    public static void log(String message){
        try(FileWriter fileWriter=new FileWriter("app.log",true)){
            fileWriter.write(System.currentTimeMillis()+" "+message+"\n");
        }catch(Exception e){}
    }
}
