package com.mycompany.javafxapplication1;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class SecondaryController{
    @FXML private TextField userTextField;
    @FXML private TableView dataTableView;
    @FXML private Button secondaryButton;
    @FXML private Button refreshBtn;
    @FXML private TextField customTextField;
    @FXML private Button editBtn;
    @FXML private Button deleteBtn;
    @FXML private TextArea terminalOutputTextArea;
    @FXML private TextField terminalInputTextField;
    @FXML private Label metricsLabel;
    private final Terminal terminal=new Terminal();

    @FXML private TextField fileNameTextField;
    @FXML private TextArea fileContentTextArea;
    @FXML private Button openFileBtn;
    @FXML private Button createFileBtn;
    @FXML private Button saveFileBtn;
    @FXML private Button deleteFileBtn;
    @FXML private Label fileStatusLabel;

    @FXML private TextField shareUserTextField;
    @FXML private CheckBox shareWriteCheckBox;
    @FXML private Button shareFileBtn;
    @FXML private Button revokeShareBtn;

    private String currentUsername="";
    private String currentRole="standard";

    private int storageRRIndex=0;

    @FXML private void RefreshBtnHandler(ActionEvent event){
        Stage primaryStage=(Stage)customTextField.getScene().getWindow();
        customTextField.setText((String)primaryStage.getUserData());
    }

    @FXML private void switchToPrimary(){
        Stage secondaryStage=new Stage();
        Stage primaryStage=(Stage)secondaryButton.getScene().getWindow();
        try{
            Object ud=primaryStage.getUserData();
            if(ud!=null){
                DB db=new DB();
                db.deleteSession(String.valueOf(ud));
            }
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource("primary.fxml"));
            Parent root=loader.load();
            Scene scene=new Scene(root,640,480);
            secondaryStage.setScene(scene);
            secondaryStage.setTitle("Login");
            secondaryStage.show();
            primaryStage.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void initialise(String[] credentials){
        userTextField.setText(credentials[0]);
        currentUsername=credentials[0];
        currentRole=credentials!=null&&credentials.length>1&&credentials[1]!=null?credentials[1]:"standard";
        DB myObj=new DB();
        ObservableList<User> data;
        try{
            boolean admin=false;
            if(credentials!=null&&credentials.length>1&&credentials[1]!=null){
                admin="admin".equalsIgnoreCase(credentials[1]);
            }
            if(editBtn!=null)editBtn.setDisable(!admin);
            if(deleteBtn!=null)deleteBtn.setDisable(!admin);
            data=myObj.getDataFromTable();
            TableColumn user=new TableColumn("User");
            user.setCellValueFactory(new PropertyValueFactory<>("user"));
            TableColumn pass=new TableColumn("Pass");
            pass.setCellValueFactory(new PropertyValueFactory<>("pass"));
            TableColumn r=new TableColumn("Role");
            r.setCellValueFactory(new PropertyValueFactory<>("role"));
            dataTableView.setItems(data);
            dataTableView.getColumns().addAll(user,pass,r);
            updateMetricsLabel();
        }catch(ClassNotFoundException ex){
            Logger.getLogger(SecondaryController.class.getName()).log(Level.SEVERE,null,ex);
        }
    }

    @FXML private void editBtnHandler(ActionEvent event){
        User selected=(User)dataTableView.getSelectionModel().getSelectedItem();
        if(selected==null)return;
        TextInputDialog dialog=new TextInputDialog(selected.getUser());
        dialog.setTitle("Edit User");
        dialog.setHeaderText(null);
        dialog.setContentText("New username:");
        String newName=dialog.showAndWait().orElse("").trim();
        if(newName.isEmpty())return;
        DB db=new DB();
        try{
            boolean ok=db.updateUserName(selected.getUser(),newName);
            AppLog.log("edit user "+selected.getUser()+" -> "+newName+" ok="+ok);
            if(ok)reloadUsers();
        }catch(ClassNotFoundException ex){
            Logger.getLogger(SecondaryController.class.getName()).log(Level.SEVERE,null,ex);
        }
    }


    @FXML private void deleteBtnHandler(ActionEvent event){
        User selected=(User)dataTableView.getSelectionModel().getSelectedItem();
        if(selected==null)return;
        DB db=new DB();
        try{
            boolean ok=db.deleteUserByName(selected.getUser());
            AppLog.log("delete user "+selected.getUser()+" ok="+ok);
            if(ok)reloadUsers();
        }catch(ClassNotFoundException ex){
            Logger.getLogger(SecondaryController.class.getName()).log(Level.SEVERE,null,ex);
        }
    }

    private void reloadUsers(){
        DB db=new DB();
        try{
            dataTableView.setItems(db.getDataFromTable());
        }catch(ClassNotFoundException ex){
            Logger.getLogger(SecondaryController.class.getName()).log(Level.SEVERE,null,ex);
        }
    }
    
    private void updateMetricsLabel(){
        if(metricsLabel!=null)metricsLabel.setText(Metrics.text());
    }

    @FXML private void terminalInputHandler(ActionEvent event){
        String commandText=terminalInputTextField.getText();
        terminalInputTextField.clear();
        if(commandText==null)return;
        terminalOutputTextArea.appendText(terminal.prompt()+commandText+"\n");
        long startTimeMilliseconds=System.currentTimeMillis();
        String outputText=terminal.run(commandText);
        long durationMilliseconds=System.currentTimeMillis()-startTimeMilliseconds;
        Metrics.record(durationMilliseconds);
        AppLog.log("terminal "+commandText+" ms="+durationMilliseconds);
        updateMetricsLabel();
        if(outputText!=null&&!outputText.isEmpty())terminalOutputTextArea.appendText(outputText+"\n");
    }

    private java.io.File resolveFile(){
        String name=fileNameTextField==null?null:fileNameTextField.getText();
        if(name==null)return null;
        String trimmed=name.trim();
        if(trimmed.isEmpty())return null;
        return new java.io.File(trimmed).getAbsoluteFile();
    }

    private void setFileStatus(String text){
        String out=text;
        try{
            java.io.File f=resolveFile();
            if(f!=null){
                DB db=new DB();
                String summary=db.getFileMetaSummary(f.getAbsolutePath());
                if(summary!=null&&!summary.trim().isEmpty())out=out+" | "+summary;
            }
        }catch(Exception e){
        }
        if(fileStatusLabel!=null)fileStatusLabel.setText(out);
    }

    private void cacheFileMeta(java.io.File f,String action){
        try{
            if(f==null)return;
            DB db=new DB();
            String owner=db.getFileOwner(f.getAbsolutePath());
            if(owner==null||owner.trim().isEmpty())owner=currentUsername;
            db.upsertFileMeta(f.getAbsolutePath(),owner,f.length(),action);
            try{
                MySQLDB mysqlDB=new MySQLDB();
                mysqlDB.createTables();
                mysqlDB.upsertFileMeta(f.getAbsolutePath(),owner,f.length(),action);
            }catch(Exception e){
            }
        }catch(Exception e){
        }
    }

    private void clearFileMeta(java.io.File f){
        try{
            if(f==null)return;
            DB db=new DB();
            db.deleteFileMeta(f.getAbsolutePath());
            try{
                MySQLDB mysqlDB=new MySQLDB();
                mysqlDB.createTables();
                mysqlDB.deleteFileAclAndShare(f.getAbsolutePath());
            }catch(Exception e){
            }
        }catch(Exception e){
        }
    }

    private boolean isAdmin(){
        return currentRole!=null&&currentRole.equalsIgnoreCase("admin");
    }

    private boolean isOwner(java.io.File f){
        try{
            DB db=new DB();
            String owner=db.getFileOwner(f.getAbsolutePath());
            if(owner==null||owner.trim().isEmpty())return false;
            return owner.equals(currentUsername);
        }catch(Exception e){
            return false;
        }
    }

    private int getShareWrite(java.io.File f){
        try{
            DB db=new DB();
            return db.getFileShareCanWrite(f.getAbsolutePath(),currentUsername);
        }catch(Exception e){
            return -1;
        }
    }

    private boolean canRead(java.io.File f){
        if(isAdmin())return true;
        if(isOwner(f))return true;
        return getShareWrite(f)>=0;
    }

    private boolean canWrite(java.io.File f){
        if(isAdmin())return true;
        if(isOwner(f))return true;
        return getShareWrite(f)==1;
    }

    private boolean canDelete(java.io.File f){
        if(isAdmin())return true;
        return isOwner(f);
    }

    private String remoteFilePath(java.io.File f){
        if(f==null)return null;
        String name=f.getName();
        if(name==null)return null;
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<name.length();i++){
            char c=name.charAt(i);
            if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='.'||c=='-'||c=='_'){
                sb.append(c);
            }else{
                sb.append('_');
            }
        }
        return "/files/"+sb.toString();
    }

    private String[] storageHosts(){
        return new String[]{"fileserver1","fileserver2","fileserver3","fileserver4"};
    }

    private int nextStorageIndex(){
        int idx=storageRRIndex;
        storageRRIndex++;
        return idx;
    }

    private boolean remoteWriteText(java.io.File f,String text){
        String remote=remoteFilePath(f);
        if(remote==null)return false;
        String[] hosts=storageHosts();
        int start=0;
        try{
            start=nextStorageIndex()%hosts.length;
        }catch(Exception e){
            start=0;
        }
        for(int i=0;i<hosts.length;i++){
            String host=hosts[(start+i)%hosts.length];
            com.jcraft.jsch.Session session=null;
            com.jcraft.jsch.Channel channel=null;
            try{
                com.jcraft.jsch.JSch jsch=new com.jcraft.jsch.JSch();
                session=jsch.getSession("ntu-user",host,22);
                session.setPassword("ntu-user");
                java.util.Properties config=new java.util.Properties();
                config.put("StrictHostKeyChecking","no");
                session.setConfig(config);
                session.connect(5000);
                channel=session.openChannel("sftp");
                channel.connect(5000);
                com.jcraft.jsch.ChannelSftp sftp=(com.jcraft.jsch.ChannelSftp)channel;
                java.io.ByteArrayInputStream in=new java.io.ByteArrayInputStream((text==null?"":text).getBytes(java.nio.charset.StandardCharsets.UTF_8));
                sftp.put(in,remote);
                in.close();
                sftp.exit();
                channel.disconnect();
                session.disconnect();
                return true;
            }catch(Exception e){
                try{
                    if(channel!=null)channel.disconnect();
                }catch(Exception ex){
                }
                try{
                    if(session!=null)session.disconnect();
                }catch(Exception ex){
                }
            }
        }
        return false;
    }

    private String remoteReadText(java.io.File f){
        String remote=remoteFilePath(f);
        if(remote==null)return null;
        String[] hosts=storageHosts();
        for(int i=0;i<hosts.length;i++){
            String host=hosts[i];
            com.jcraft.jsch.Session session=null;
            com.jcraft.jsch.Channel channel=null;
            try{
                com.jcraft.jsch.JSch jsch=new com.jcraft.jsch.JSch();
                session=jsch.getSession("ntu-user",host,22);
                session.setPassword("ntu-user");
                java.util.Properties config=new java.util.Properties();
                config.put("StrictHostKeyChecking","no");
                session.setConfig(config);
                session.connect(5000);
                channel=session.openChannel("sftp");
                channel.connect(5000);
                com.jcraft.jsch.ChannelSftp sftp=(com.jcraft.jsch.ChannelSftp)channel;
                java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();
                sftp.get(remote,out);
                String text=new String(out.toByteArray(),java.nio.charset.StandardCharsets.UTF_8);
                out.close();
                sftp.exit();
                channel.disconnect();
                session.disconnect();
                return text;
            }catch(Exception e){
                try{
                    if(channel!=null)channel.disconnect();
                }catch(Exception ex){
                }
                try{
                    if(session!=null)session.disconnect();
                }catch(Exception ex){
                }
            }
        }
        return null;
    }

    private boolean remoteDelete(java.io.File f){
        String remote=remoteFilePath(f);
        if(remote==null)return false;
        String[] hosts=storageHosts();
        for(int i=0;i<hosts.length;i++){
            String host=hosts[i];
            com.jcraft.jsch.Session session=null;
            com.jcraft.jsch.Channel channel=null;
            try{
                com.jcraft.jsch.JSch jsch=new com.jcraft.jsch.JSch();
                session=jsch.getSession("ntu-user",host,22);
                session.setPassword("ntu-user");
                java.util.Properties config=new java.util.Properties();
                config.put("StrictHostKeyChecking","no");
                session.setConfig(config);
                session.connect(5000);
                channel=session.openChannel("sftp");
                channel.connect(5000);
                com.jcraft.jsch.ChannelSftp sftp=(com.jcraft.jsch.ChannelSftp)channel;
                try{
                    sftp.rm(remote);
                    sftp.exit();
                    channel.disconnect();
                    session.disconnect();
                    return true;
                }catch(Exception e){
                    sftp.exit();
                    channel.disconnect();
                    session.disconnect();
                }
            }catch(Exception e){
                try{
                    if(channel!=null)channel.disconnect();
                }catch(Exception ex){
                }
                try{
                    if(session!=null)session.disconnect();
                }catch(Exception ex){
                }
            }
        }
        return false;
    }

    @FXML private void openFileBtnHandler(ActionEvent event){
        java.io.File f=resolveFile();
        if(f==null){setFileStatus("Enter a filename");return;}
        if(!f.exists()){setFileStatus("File not found");return;}
        if(f.isDirectory()){setFileStatus("Is a directory");return;}
        if(!canRead(f)){setFileStatus("Access denied");return;}
        try{
            String encryptedText=null;
            try{
                encryptedText=remoteReadText(f);
            }catch(Exception e){
            }
            if(encryptedText==null){
                StringBuilder sb=new StringBuilder();
                try(java.io.BufferedReader br=new java.io.BufferedReader(new java.io.FileReader(f))){
                    String line;
                    while((line=br.readLine())!=null)sb.append(line);
                }
                encryptedText=sb.toString();
            }
            DB db=new DB();
            String plain=db.decryptText(encryptedText);
            if(plain==null){setFileStatus("Decrypt failed");return;}
            if(fileContentTextArea!=null)fileContentTextArea.setText(plain);
            cacheFileMeta(f,"Opened");
            setFileStatus("Opened");
        }catch(Exception e){
            setFileStatus("Open failed");
        }
    }

    @FXML private void createFileBtnHandler(ActionEvent event){
        java.io.File f=resolveFile();
        if(f==null){setFileStatus("Enter a filename");return;}
        if(f.exists()){setFileStatus("File already exists");return;}
        try{
            java.io.File parent=f.getParentFile();
            if(parent!=null)parent.mkdirs();
            boolean created=f.createNewFile();
            if(!created){setFileStatus("Create failed");return;}
            String content=fileContentTextArea==null?"":fileContentTextArea.getText();
            DB db=new DB();
            String encrypted=db.encryptText(content==null?"":content);
            if(encrypted==null){setFileStatus("Encrypt failed");return;}
            String verify=db.decryptText(encrypted);
            if(verify==null||!verify.equals(content==null?"":content)){setFileStatus("Verify failed");return;}
            try(java.io.FileWriter fw=new java.io.FileWriter(f,false)){
                fw.write(encrypted);
            }
            boolean remoteOk=remoteWriteText(f,encrypted);
            try{
                db.setFileOwner(f.getAbsolutePath(),currentUsername);
            }catch(Exception e){
            }
            try{
                MySQLDB mysqlDB=new MySQLDB();
                mysqlDB.createTables();
                mysqlDB.setFileOwner(f.getAbsolutePath(),currentUsername);
            }catch(Exception e){
            }
            cacheFileMeta(f,"Created");
            setFileStatus(remoteOk?"Created":"Created (remote failed)");
        }catch(Exception e){
            setFileStatus("Create failed");
        }
    }

    @FXML private void saveFileBtnHandler(ActionEvent event){
        java.io.File f=resolveFile();
        if(f==null){setFileStatus("Enter a filename");return;}
        if(!f.exists()){setFileStatus("File not found");return;}
        if(f.isDirectory()){setFileStatus("Is a directory");return;}
        if(!canWrite(f)){setFileStatus("Access denied");return;}
        try{
            String content=fileContentTextArea==null?"":fileContentTextArea.getText();
            DB db=new DB();
            String encrypted=db.encryptText(content==null?"":content);
            if(encrypted==null){setFileStatus("Encrypt failed");return;}
            String verify=db.decryptText(encrypted);
            if(verify==null||!verify.equals(content==null?"":content)){setFileStatus("Verify failed");return;}
            try(java.io.FileWriter fw=new java.io.FileWriter(f,false)){
                fw.write(encrypted);
            }
            boolean remoteOk=remoteWriteText(f,encrypted);
            cacheFileMeta(f,"Saved");
            setFileStatus(remoteOk?"Saved":"Saved (remote failed)");
        }catch(Exception e){
            setFileStatus("Save failed");
        }
    }

    @FXML private void deleteFileBtnHandler(ActionEvent event){
        java.io.File f=resolveFile();
        if(f==null){setFileStatus("Enter a filename");return;}
        if(!f.exists()){setFileStatus("File not found");return;}
        if(f.isDirectory()){setFileStatus("Is a directory");return;}
        if(!canDelete(f)){setFileStatus("Access denied");return;}
        try{
            boolean remoteOk=remoteDelete(f);
            cacheFileMeta(f,"Deleted");
            boolean deleted=f.delete();
            if(!deleted){setFileStatus("Delete failed");return;}
            if(fileContentTextArea!=null)fileContentTextArea.clear();
            clearFileMeta(f);
            setFileStatus(remoteOk?"Deleted":"Deleted (remote failed)");
        }catch(Exception e){
            setFileStatus("Delete failed");
        }
    }

    @FXML private void shareFileBtnHandler(ActionEvent event){
        java.io.File f=resolveFile();
        if(f==null){setFileStatus("Enter a filename");return;}
        if(!f.exists()){setFileStatus("File not found");return;}
        if(f.isDirectory()){setFileStatus("Is a directory");return;}
        if(!(isAdmin()||isOwner(f))){setFileStatus("Access denied");return;}
        String target=shareUserTextField==null?null:shareUserTextField.getText();
        if(target==null||target.trim().isEmpty()){setFileStatus("Enter a username");return;}
        int canWriteValue=shareWriteCheckBox!=null&&shareWriteCheckBox.isSelected()?1:0;
        try{
            DB db=new DB();
            boolean ok=db.setFileShare(f.getAbsolutePath(),target.trim(),canWriteValue);
            try{
                MySQLDB mysqlDB=new MySQLDB();
                mysqlDB.createTables();
                mysqlDB.setFileShare(f.getAbsolutePath(),target.trim(),canWriteValue);
            }catch(Exception e){
            }
            AppLog.log("share file "+f.getAbsolutePath()+" to "+target.trim()+" write="+canWriteValue+" ok="+ok);
            setFileStatus(ok?"Shared":"Share failed");
        }catch(Exception e){
            setFileStatus("Share failed");
        }
    }

    @FXML private void revokeShareBtnHandler(ActionEvent event){
        java.io.File f=resolveFile();
        if(f==null){setFileStatus("Enter a filename");return;}
        if(!f.exists()){setFileStatus("File not found");return;}
        if(f.isDirectory()){setFileStatus("Is a directory");return;}
        if(!(isAdmin()||isOwner(f))){setFileStatus("Access denied");return;}
        String target=shareUserTextField==null?null:shareUserTextField.getText();
        if(target==null||target.trim().isEmpty()){setFileStatus("Enter a username");return;}
        try{
            DB db=new DB();
            boolean ok=db.removeFileShare(f.getAbsolutePath(),target.trim());
            try{
                MySQLDB mysqlDB=new MySQLDB();
                mysqlDB.createTables();
                mysqlDB.removeFileShare(f.getAbsolutePath(),target.trim());
            }catch(Exception e){
            }
            AppLog.log("revoke share "+f.getAbsolutePath()+" from "+target.trim()+" ok="+ok);
            setFileStatus(ok?"Revoked":"Revoke failed");
        }catch(Exception e){
            setFileStatus("Revoke failed");
        }   
    }
}
