package com.mycompany.javafxapplication1;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

public class Terminal{
    private File workingDirectory=new File(".").getAbsoluteFile();
    public String prompt(){return workingDirectory.getAbsolutePath()+" $ ";}
    public String run(String commandText){
        if(commandText==null)return"";
        String trimmedCommandText=commandText.trim();
        if(trimmedCommandText.isEmpty())return"";
        String[] commandTokens=trimmedCommandText.split("\\s+");
        String commandName=commandTokens[0];
        if(commandName.equals("pwd"))return workingDirectory.getAbsolutePath();
        if(commandName.equals("cd")){
            if(commandTokens.length<2)return"Usage: cd <path>";
            String pathArgument=commandTokens[1];
            File targetDirectory=pathArgument.startsWith("/")?new File(pathArgument):new File(workingDirectory,pathArgument);
            targetDirectory=targetDirectory.getAbsoluteFile();
            if(!targetDirectory.exists())return"cd: no such directory";
            if(!targetDirectory.isDirectory())return"cd: not a directory";
            workingDirectory=targetDirectory;
            return"";
        }
        if(commandName.equals("nano")){
            if(commandTokens.length<2)return"Usage: nano <file>";
            try{
                File fileToEdit=new File(workingDirectory,commandTokens[1]).getAbsoluteFile();
                ProcessBuilder processBuilder=new ProcessBuilder("xterm","-e","nano",fileToEdit.getAbsolutePath());
                processBuilder.directory(workingDirectory);
                processBuilder.start();
                return"";
            }catch(Exception exception){
                return"nano: failed";
            }
        }
        if(!(commandName.equals("mv")||commandName.equals("cp")||commandName.equals("ls")||commandName.equals("mkdir")||commandName.equals("ps")||commandName.equals("whoami")||commandName.equals("tree")))return"Unknown command";
        try{
            ProcessBuilder processBuilder=new ProcessBuilder(commandTokens);
            processBuilder.directory(workingDirectory);
            processBuilder.redirectErrorStream(true);
            Process process=processBuilder.start();
            StringBuilder outputBuilder=new StringBuilder();
            try(BufferedReader reader=new BufferedReader(new InputStreamReader(process.getInputStream()))){
                String outputLine;
                while((outputLine=reader.readLine())!=null)outputBuilder.append(outputLine).append("\n");
            }
            process.waitFor();
            return outputBuilder.toString().trim();
        }catch(Exception exception){
            return commandName+": failed";
        }
    }
}
