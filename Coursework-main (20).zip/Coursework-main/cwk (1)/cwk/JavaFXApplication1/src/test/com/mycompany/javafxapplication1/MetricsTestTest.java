package com.mycompany.javafxapplication1;

import org.junit.Test;
import static org.junit.Assert.*;

public class MetricsTestTest {

    @Test
    public void resetClearsAllValues() {
        Metrics.reset();
        assertEquals(0, Metrics.getCommandCount());
        assertEquals(0, Metrics.getLastDuration());
        assertEquals(0, Metrics.getAverageDuration());
        assertEquals(0.0, Metrics.getThroughput(), 0.0001);
    }

    @Test
    public void recordUpdatesCountLastAndAverage() {
        Metrics.reset();

        Metrics.record(100);
        assertEquals(1, Metrics.getCommandCount());
        assertEquals(100, Metrics.getLastDuration());
        assertEquals(100, Metrics.getAverageDuration());

        Metrics.record(300);
        assertEquals(2, Metrics.getCommandCount());
        assertEquals(300, Metrics.getLastDuration());
        assertEquals(200, Metrics.getAverageDuration());

        String t = Metrics.text();
        assertTrue(t.contains("Commands:"));
        assertTrue(t.contains("LastMs:"));
        assertTrue(t.contains("AvgMs:"));
        assertTrue(t.contains("Throughput:"));
    }
}