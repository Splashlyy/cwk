package com.mycompany.javafxapplication1;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class AppLogTestTest {

    @Test
    public void logCreatesAndAppendsToFile() throws Exception {
        File logFile = new File("app.log");
        if (logFile.exists()) logFile.delete();

        String message = "test message";
        AppLog.log(message);

        assertTrue(logFile.exists());

        List<String> lines = Files.readAllLines(Paths.get("app.log"), StandardCharsets.UTF_8);
        assertTrue(lines.size() >= 1);
        assertTrue(lines.get(lines.size() - 1).contains(message));
    }
}
